const socket = io();

let currentUser = null;
let currentRoom = 'public';
let typingTimeout = null;

// DOM Elements
const loginScreen = document.getElementById('login-screen');
const app = document.getElementById('app');
const usernameInput = document.getElementById('username-input');
const joinBtn = document.getElementById('join-btn');
const messagesList = document.getElementById('messages-list');
const messagesContainer = document.getElementById('messages-container');
const messageInput = document.getElementById('message-input');
const sendBtn = document.getElementById('send-btn');
const myAvatar = document.getElementById('my-avatar');
const currentRoomName = document.getElementById('current-room-name');
const currentRoomStatus = document.getElementById('current-room-status');
const currentRoomAvatar = document.getElementById('current-room-avatar');
const typingIndicator = document.getElementById('typing-indicator');
const typingText = document.getElementById('typing-text');
const logoutBtn = document.getElementById('logout-btn');

// Room names and icons
const roomInfo = {
    public: { name: 'الغرفة العامة', icon: '👥', color: '#25D366' },
    support: { name: 'غرفة الدعم', icon: '🛠️', color: '#128C7E' }
};

// Join
joinBtn.addEventListener('click', joinChat);
usernameInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') joinChat();
});

function joinChat() {
    const username = usernameInput.value.trim();
    if (!username) {
        alert('الرجاء إدخال اسم المستخدم');
        return;
    }
    const room = document.querySelector('input[name="room"]:checked').value;
    currentRoom = room;
    socket.emit('join', { username, room });
}

socket.on('joined', (data) => {
    currentUser = data.username;
    currentRoom = data.room;
    
    loginScreen.classList.add('hidden');
    app.classList.remove('hidden');
    
    myAvatar.textContent = currentUser.charAt(0).toUpperCase();
    myAvatar.style.background = data.avatar_color || '#25D366';
    
    updateRoomUI(data.room, data.room_name, data.users);
    
    // Clear and load messages
    messagesList.innerHTML = '';
    data.messages.forEach(msg => appendMessage(msg));
    scrollToBottom();
    
    // Highlight active chat
    document.querySelectorAll('.chat-item').forEach(item => {
        item.classList.toggle('active', item.dataset.room === data.room);
    });
});

socket.on('error', (data) => {
    alert(data.message);
});

// Send message
function sendMessage() {
    const text = messageInput.value.trim();
    if (!text) return;
    socket.emit('send_message', { text });
    messageInput.value = '';
    socket.emit('typing', { is_typing: false });
}

sendBtn.addEventListener('click', sendMessage);
messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});

// Typing
messageInput.addEventListener('input', () => {
    socket.emit('typing', { is_typing: true });
    clearTimeout(typingTimeout);
    typingTimeout = setTimeout(() => {
        socket.emit('typing', { is_typing: false });
    }, 1500);
});

socket.on('new_message', (msg) => {
    appendMessage(msg);
    scrollToBottom();
    
    // Update preview
    const preview = document.getElementById(`${currentRoom}-preview`);
    const timeEl = document.getElementById(`${currentRoom}-time`);
    if (preview) {
        const prefix = msg.username === currentUser ? 'أنت: ' : msg.username + ': ';
        preview.textContent = prefix + (msg.text.length > 30 ? msg.text.slice(0, 30) + '...' : msg.text);
    }
    if (timeEl) timeEl.textContent = msg.timestamp;
});

socket.on('user_joined', (data) => {
    if (data.room === currentRoom) {
        currentRoomStatus.textContent = `${data.users_count} متصل`;
        appendSystemMessage(`${data.username} انضم إلى الغرفة`);
    }
});

socket.on('user_left', (data) => {
    if (data.room === currentRoom) {
        currentRoomStatus.textContent = `${data.users_count} متصل`;
        appendSystemMessage(`${data.username} غادر الغرفة`);
    }
});

socket.on('user_typing', (data) => {
    if (data.is_typing) {
        typingText.textContent = `${data.username} يكتب...`;
        typingIndicator.style.display = 'block';
    } else {
        typingIndicator.style.display = 'none';
    }
});

socket.on('messages_cleared', () => {
    messagesList.innerHTML = '';
    appendSystemMessage('تم مسح الرسائل بواسطة الإدارة');
});

// Switch rooms
document.querySelectorAll('.chat-item').forEach(item => {
    item.addEventListener('click', () => {
        const room = item.dataset.room;
        if (room === currentRoom) return;
        socket.emit('switch_room', { room });
    });
});

function updateRoomUI(roomId, roomName, users) {
    currentRoomName.textContent = roomName || roomInfo[roomId].name;
    currentRoomStatus.textContent = `${users ? users.length : 0} متصل`;
    currentRoomAvatar.textContent = roomInfo[roomId].icon;
    currentRoomAvatar.style.background = roomInfo[roomId].color;
}

function appendMessage(msg) {
    const div = document.createElement('div');
    
    if (msg.is_system) {
        div.className = 'message system';
        div.innerHTML = `<div class="message-text">${escapeHtml(msg.text)}</div>`;
    } else {
        const isOut = msg.username === currentUser;
        div.className = `message ${isOut ? 'outgoing' : 'incoming'}`;
        
        let html = '';
        if (!isOut) {
            html += `<div class="message-sender" style="color:${msg.avatar_color || '#53bdeb'}">${escapeHtml(msg.username)}</div>`;
        }
        html += `<div class="message-text">${escapeHtml(msg.text)}</div>`;
        html += `<div class="message-meta">
                    <span class="message-time">${msg.timestamp}</span>
                    ${isOut ? '<span class="message-status">✓✓</span>' : ''}
                 </div>`;
        div.innerHTML = html;
    }
    
    messagesList.appendChild(div);
}

function appendSystemMessage(text) {
    const div = document.createElement('div');
    div.className = 'message system';
    div.innerHTML = `<div class="message-text">${escapeHtml(text)}</div>`;
    messagesList.appendChild(div);
    scrollToBottom();
}

function scrollToBottom() {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

logoutBtn.addEventListener('click', () => {
    location.reload();
});

// Focus input
messageInput.addEventListener('focus', () => {
    setTimeout(scrollToBottom, 100);
});
