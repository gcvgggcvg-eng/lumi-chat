const socket = io();

const loginAdmin = document.getElementById('login-admin');
const adminPanel = document.getElementById('admin-panel');
const adminPassword = document.getElementById('admin-password');
const adminLoginBtn = document.getElementById('admin-login-btn');
const logoutAdmin = document.getElementById('logout-admin');
const onlineCount = document.getElementById('online-count');
const roomsContainer = document.getElementById('rooms-container');
const onlineList = document.getElementById('online-list');
const broadcastInput = document.getElementById('broadcast-input');
const broadcastBtn = document.getElementById('broadcast-btn');

adminLoginBtn.addEventListener('click', () => {
    const password = adminPassword.value;
    socket.emit('join_admin', { password });
});

adminPassword.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') adminLoginBtn.click();
});

socket.on('admin_joined', (data) => {
    loginAdmin.classList.add('hidden');
    adminPanel.classList.remove('hidden');
    updateAdminUI(data);
});

socket.on('error', (data) => {
    alert(data.message);
});

socket.on('admin_update', (data) => {
    updateAdminUI(data);
});

function updateAdminUI(data) {
    onlineCount.textContent = `${data.online_count} متصل`;
    
    // Online users
    onlineList.innerHTML = '';
    data.online_users.forEach(u => {
        const li = document.createElement('li');
        li.textContent = u;
        onlineList.appendChild(li);
    });
    
    // Rooms
    roomsContainer.innerHTML = '';
    data.rooms.forEach(room => {
        const card = document.createElement('div');
        card.className = 'room-card';
        
        let messagesHtml = '';
        if (room.last_messages && room.last_messages.length) {
            room.last_messages.slice().reverse().forEach(m => {
                messagesHtml += `<div class="msg-preview"><span class="user">${escapeHtml(m.username)}</span>: ${escapeHtml(m.text.slice(0, 50))}</div>`;
            });
        } else {
            messagesHtml = '<div style="color:#64748b">لا توجد رسائل</div>';
        }
        
        card.innerHTML = `
            <h3>${escapeHtml(room.name)} <span style="font-size:13px;color:#94a3b8">#${room.id}</span></h3>
            <div class="stats">
                <span>👥 ${room.user_count} مستخدم</span>
                <span>💬 ${room.message_count} رسالة</span>
            </div>
            <div class="users-list">
                ${room.users.length ? 'المتصلون: ' + room.users.map(u => escapeHtml(u)).join('، ') : 'لا يوجد متصلون'}
            </div>
            <div class="messages-preview">${messagesHtml}</div>
            <button onclick="clearRoom('${room.id}')">مسح الرسائل</button>
        `;
        roomsContainer.appendChild(card);
    });
}

window.clearRoom = function(roomId) {
    if (confirm('هل أنت متأكد من مسح جميع رسائل هذه الغرفة؟')) {
        socket.emit('admin_clear_messages', { room: roomId });
    }
};

broadcastBtn.addEventListener('click', () => {
    const text = broadcastInput.value.trim();
    if (!text) return;
    socket.emit('admin_broadcast', { text });
    broadcastInput.value = '';
});

logoutAdmin.addEventListener('click', () => {
    location.reload();
});

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
